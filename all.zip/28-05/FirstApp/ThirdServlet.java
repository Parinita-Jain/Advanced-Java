package com.itvedant;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ThirdServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		
		PrintWriter out = resp.getWriter();
		
		String name = req.getParameter("name");
		float marks = Float.parseFloat(req.getParameter("marks"));
		String color = req.getParameter("color");
		
		float aggregate = ( marks / 500 ) * 100;
		
		out.print("<p style='color:" + color + "';>");
		out.print("Hello, " + name);
		out.print("<br/>You have scored: " + aggregate + "%");
		out.print("</p>");
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
