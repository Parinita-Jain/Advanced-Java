package com.itvedant;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HomeServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		PrintWriter out = resp.getWriter();
		resp.setContentType("text/html");
		
		out.print("<form action='validate' method='get'>");
		out.print("<table><tr><td>Name:</td>");
		out.print("<td><input type='text' name='name'/></td>");
		out.print("</tr><tr><td>Marks:</td>");
		out.print("<td><input type='number' name='marks'/></td>");
		out.print("</tr><tr><td>Color:</td><td>");
		out.print("<select name='color'>");
		out.print("<option value='none'>.....</option>");
		out.print("<option>Red</option>");
		out.print("<option>Blue</option>");
		out.print("<option>Green</option>");
		out.print("<option>Pink</option>");
		out.print("<option>Purple</option>");
		out.print("<option>Grey</option>");
		out.print("<option>Violet</option>");
		out.print("<option>Indigo</option>");
		out.print("</select></td></tr><tr>");
		out.print("<td><input type='submit' value='OK'/></td>");
		out.print("<td><input type='reset'/></td></tr></table></form>");
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}
}
