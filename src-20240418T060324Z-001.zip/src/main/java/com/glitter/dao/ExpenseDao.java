package com.glitter.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.glitter.model.Expense;
import com.glitter.model.Income;
import com.glitter.model.User;
import com.glitter.util.DBConnect;

public class ExpenseDao {
	Connection con = DBConnect.getConnection();

	public boolean addExpense(Expense inc) {
		String sql = "insert into expense(expense,expense_type,description,user_id) values(?,?,?,?)";
		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setDouble(1, inc.getExpense());
			ps.setString(2, inc.getExpenseType());
			ps.setString(3, inc.getDescription());
			ps.setInt(4, inc.getUserId());
			
			int i = ps.executeUpdate();
			
			if(i>0) {
				return true;
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public List<Expense> getExpenseList(int uid){
		List<Expense> expList = new ArrayList<Expense>();
		
		String sql = "select * from expense where user_id=?";
		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, uid);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				Expense exp = new Expense();
				exp.setId(rs.getInt("id"));
				exp.setExpense(rs.getDouble("expense"));
				exp.setExpenseType(rs.getString("expense_type"));
				exp.setExpenseDate(rs.getDate("expense_date").toString());
				exp.setDescription(rs.getString("description"));
				exp.setUserId(rs.getInt("user_id"));
				
				expList.add(exp);
			}
			
			return expList;
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public double getTotalExpense(User user) {
		String sql = "select sum(expense) as totalexpense from expense where user_id=?";
		
		try {
			
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, user.getId());
			
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				return rs.getDouble("totalexpense");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return 0;
	}
	
	public boolean deleteExpense(int id) {
		String sql = "delete from expense where id=?";
		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			
			int i = ps.executeUpdate();
			
			if(i>0) {
				return true;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	public Expense getExpense(int id) {
		String sql = "select * from Expense where id=?";
		
		try {
			
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				Expense exp = new Expense();
				exp.setId(rs.getInt("id"));
				exp.setExpense(rs.getDouble("expense"));
				exp.setExpenseType(rs.getString("expense_type"));
				exp.setExpenseDate(rs.getDate("expense_date").toString());
				exp.setDescription(rs.getString("description"));
				exp.setUserId(rs.getInt("user_id"));
				
				return exp;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	
	public boolean updateExpense(Expense exp) {
		String sql = "update expense set expense=?, expense_type=?, description=?, user_id=? where id=?";
		
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setDouble(1, exp.getExpense());
			ps.setString(2, exp.getExpenseType());
			ps.setString(3, exp.getDescription());
			ps.setInt(4, exp.getUserId());
			ps.setInt(5, exp.getId());
			
			int i = ps.executeUpdate();
			
			if(i>0) {
				return true;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}
	
	
}
