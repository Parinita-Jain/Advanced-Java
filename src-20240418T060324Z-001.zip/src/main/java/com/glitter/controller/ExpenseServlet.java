package com.glitter.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.glitter.dao.ExpenseDao;
import com.glitter.dao.IncomeDao;
import com.glitter.model.Expense;
import com.glitter.model.Income;
import com.glitter.model.User;

@WebServlet("/ExpenseServlet")
public class ExpenseServlet extends HttpServlet {	
	Expense exp = new Expense();
	ExpenseDao expd = new ExpenseDao();
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession();
		
		User user = (User) session.getAttribute("user");
		
		String action = req.getParameter("action");
		
		if(action!=null && action.equals("delete")) {
			int id = Integer.parseInt(req.getParameter("id"));
			
			boolean b = expd.deleteExpense(id);
			
			if(b) {
				resp.sendRedirect("ExpenseServlet");
			}
		}
		else if(action!=null && action.equals("edit")) {
			int id = Integer.parseInt(req.getParameter("id"));
			
			Expense exp = expd.getExpense(id);
			
			session.setAttribute("exp", exp);
			
			resp.sendRedirect("updateexpense.jsp");
		}
		else {
			List<Expense> expList = expd.getExpenseList(user.getId());
			session.setAttribute("expList", expList);
			resp.sendRedirect("expenselist.jsp");
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String action = request.getParameter("action");
		
		User user = (User)session.getAttribute("user");		
		
		Double expense = Double.parseDouble(request.getParameter("expenseamount"));
		String expenseType = request.getParameter("expensetype");
		String description = request.getParameter("description");
		int userId = Integer.parseInt(request.getParameter("userid"));
		
		if(action!=null && action.equals("addexpense")) {
			exp.setExpense(expense);
			exp.setExpenseType(expenseType);
			exp.setDescription(description);
			exp.setUserId(userId);
		
			boolean b = new ExpenseDao().addExpense(exp);
			if(b) {
				response.sendRedirect("index.jsp");
			}
			else {
				response.sendRedirect("addexpense.jsp");
			}
		}
		else if(action!=null & action.equals("updateexpense")) {
			exp.setExpense(expense);
			exp.setExpenseType(expenseType);
			exp.setDescription(description);
			exp.setUserId(userId);
			
			int id = Integer.parseInt(request.getParameter("id"));
			exp.setId(id);
		
			boolean b = new ExpenseDao().updateExpense(exp);
			if(b) {
				response.sendRedirect("ExpenseServlet");
			}
		}
	}

}
